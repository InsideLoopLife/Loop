from pathlib import Path
p=Path("components/mortgage/MortgagePlannerClient.tsx")
text=p.read_text()
text=text.replace('import { useRouter } from "next/navigation";','import { useRouter, useSearchParams } from "next/navigation";')
needle='  const [modal, setModal] = useState<ModalState>(null);\n  const [addMenuOpen, setAddMenuOpen] = useState(false);'
repl='''  const [modal, setModal] = useState<ModalState>(null);\n  const searchParams = useSearchParams();\n  const [addMenuOpen, setAddMenuOpen] = useState(false);\n\n  useEffect(() => {\n    const intent = searchParams.get("intent");\n    if (!intent) return;\n    if (intent === "add_home") setModal({ type: "add_home" });\n    if (intent === "add_mortgage") setModal({ type: "add_mortgage", homeId: homes[0]?.id });\n    if (intent === "add_valuation") setModal({ type: "add_valuation", homeId: homes[0]?.id });\n    if (intent === "add_move_query") setModal({ type: "add_move_query" });\n    if (intent === "edit_home" && homes[0]) setModal({ type: "edit_home", home: homes[0] });\n  }, [searchParams, homes]);'''
if needle in text: text=text.replace(needle,repl)
p.write_text(text)
