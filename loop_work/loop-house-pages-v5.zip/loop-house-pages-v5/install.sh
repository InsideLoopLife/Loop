#!/usr/bin/env bash
set -euo pipefail
cd /workspaces/Loop/loop_work
SRC="/tmp/loop-house-pages-v5/loop-house-pages-v5/loop_work"
cp -f "$SRC/components/mortgage/HouseShell.tsx" ./components/mortgage/HouseShell.tsx
cp -f "$SRC/domains/wealth/house/house-page-data.ts" ./domains/wealth/house/house-page-data.ts
cp -f "$SRC/domains/wealth/house/HouseHomePage.tsx" ./domains/wealth/house/HouseHomePage.tsx
cp -f "$SRC/domains/wealth/house/HousePropertyPage.tsx" ./domains/wealth/house/HousePropertyPage.tsx
cp -f "$SRC/domains/wealth/house/HouseMovingCostsPage.tsx" ./domains/wealth/house/HouseMovingCostsPage.tsx
mkdir -p ./app/mortgage/property ./app/mortgage/rates ./app/mortgage/moving-costs
cp -f "$SRC/app/mortgage/page.tsx" ./app/mortgage/page.tsx
cp -f "$SRC/app/mortgage/property/page.tsx" ./app/mortgage/property/page.tsx
cp -f "$SRC/app/mortgage/rates/page.tsx" ./app/mortgage/rates/page.tsx
cp -f "$SRC/app/mortgage/moving-costs/page.tsx" ./app/mortgage/moving-costs/page.tsx
python /tmp/loop-house-pages-v5/loop-house-pages-v5/patch_house_workspace.py
python /tmp/loop-house-pages-v5/loop-house-pages-v5/patch_advanced_intents.py
npm run typecheck
cd /workspaces/Loop
git add loop_work/components/mortgage/HouseShell.tsx loop_work/components/mortgage/HouseWorkspaceOverview.tsx loop_work/components/mortgage/MortgagePlannerClient.tsx loop_work/domains/wealth/house/house-page-data.ts loop_work/domains/wealth/house/HouseHomePage.tsx loop_work/domains/wealth/house/HousePropertyPage.tsx loop_work/domains/wealth/house/HouseMovingCostsPage.tsx loop_work/app/mortgage/page.tsx loop_work/app/mortgage/property/page.tsx loop_work/app/mortgage/rates/page.tsx loop_work/app/mortgage/moving-costs/page.tsx
git diff --cached --check
git commit -m "Implement overview-first House workspace pages"
git push origin main
