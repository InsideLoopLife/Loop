from pathlib import Path
p=Path("components/mortgage/HouseWorkspaceOverview.tsx")
text=p.read_text()
repls={
 '["Overview", "#house-scenario-overview"]':'["Overview", "/mortgage"]',
 '["Property", "#house-property-summary"]':'["Property", "/mortgage/property"]',
 '["Mortgage & rates", "#house-scenario-overview"]':'["Mortgage & rates", "/mortgage/rates"]',
 '["Affordability", "#house-advanced-workspace"]':'["Affordability", "/affordability"]',
 '["Moving costs", "#house-advanced-workspace"]':'["Moving costs", "/mortgage/moving-costs"]',
 'href="#house-advanced-workspace"':'href="/mortgage/advanced"',
 'href="#house-property-summary"':'href="/mortgage/property"',
}
for a,b in repls.items(): text=text.replace(a,b)
text=text.replace('href="#house-advanced-workspace"','href="/mortgage/advanced"')
text=text.replace('href="#house-scenario-overview"','href="/mortgage/rates"')
text=text.replace('href="#house-property-summary"','href="/mortgage/property"')
p.write_text(text)
