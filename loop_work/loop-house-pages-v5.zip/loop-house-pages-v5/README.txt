LOOP House pages v5

Implements the approved flow:
/mortgage = Overview
/mortgage/property = Property
/mortgage/rates = Mortgage & rates / scenarios
/affordability = existing affordability engine
/mortgage/moving-costs = Moving costs

Population sources:
homes
home_mortgage_deals
home_valuation_sources
property_move_queries
mortgage_rate_deals / renewal recommendations / BoE benchmarks through the existing rates page

Quick actions:
Add property -> existing add-home modal
Add mortgage -> existing add-mortgage modal
Add valuation -> existing add-valuation modal
New move -> existing move-query modal
Compare rates -> /mortgage/rates

Install from /workspaces/Loop/loop_work:
unzip -o ./loop-house-pages-v5.zip -d /tmp/loop-house-pages-v5
chmod +x /tmp/loop-house-pages-v5/loop-house-pages-v5/install.sh
/tmp/loop-house-pages-v5/loop-house-pages-v5/install.sh
