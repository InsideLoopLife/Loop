LOOP House v2 overview

This update leaves the existing global header/Nav untouched.

What it adds:
- A polished House/Mortgage overview matching the approved direction.
- Desktop House sidebar with Overview / Property / Mortgage & rates / Affordability / Moving costs.
- Mortgage summary strip: balance, LTV, remaining term, repayment type.
- Current vs LOOP benchmark vs best sourced mortgage comparison cards.
- Uses existing Bank of England benchmark rows.
- Uses existing mortgage catalogue / renewal recommendation data.
- Lender URL import wired to the existing /api/house/mortgage/import-product-url endpoint.
- 2-year cost comparison and estimated saving.
- Existing full MortgagePlannerClient remains in place below as the advanced workspace, so no current functionality is removed.
- Responsive/mobile layout collapses the sidebar and stacks comparison cards.

Apply:
1. Copy HouseWorkspaceOverview.tsx to:
   loop_work/components/mortgage/HouseWorkspaceOverview.tsx
2. From the repository root run:
   git apply loop-house-v2.patch
3. npm run build
4. Commit and push.

The GitHub connector returned 403 on write, so these are ready-to-apply files rather than a direct repository commit.
