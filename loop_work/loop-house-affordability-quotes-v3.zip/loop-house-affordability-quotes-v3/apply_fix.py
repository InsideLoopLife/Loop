#!/usr/bin/env python3
from pathlib import Path
import re, shutil, sys

BUNDLE = Path(__file__).resolve().parent
FILES = BUNDLE / 'files'


def repo_root(start: Path) -> Path:
    p = start.resolve()
    for candidate in (p, p.parent):
        if (candidate / 'loop_work/components/mortgage/HouseUnifiedWorkspace.tsx').exists():
            return candidate
        if candidate.name == 'loop_work' and (candidate / 'components/mortgage/HouseUnifiedWorkspace.tsx').exists():
            return candidate.parent
    raise SystemExit('Run from /workspaces/Loop or pass /workspaces/Loop as the first argument.')


def backup(path: Path):
    if not path.exists():
        return
    target = path.with_suffix(path.suffix + '.housev3.bak')
    if not target.exists():
        shutil.copy2(path, target)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly 1 match, got {count}')
    return text.replace(old, new, 1)


def regex_once(text: str, pattern: str, replacement: str, label: str) -> str:
    out, count = re.subn(pattern, replacement, text, count=1, flags=re.S)
    if count != 1:
        raise RuntimeError(f'{label}: expected exactly 1 regex match, got {count}')
    return out


def patch_house_page(repo: Path):
    path = repo / 'loop_work/domains/wealth/house/HousePage.tsx'
    text = path.read_text()

    pattern = r'''  const normalSalaryPayEvents = \(\(payEvents \?\? \[\]\) as PayEventForPlan\[\]\)\.map\([\s\S]*?  const normalMonthPlan = buildMonthPlan\(\{[\s\S]*?    peopleById,\n  \}\);\n'''
    replacement = r'''  const payEventRows = (payEvents ?? []) as PayEventForPlan[];
  const monthKey = currentMonth();
  const [monthYear, monthNumber] = monthKey.split("-").map(Number);
  const monthStartDate = `${monthKey}-01`;
  const monthEndDate = new Date(Date.UTC(monthYear, monthNumber, 0))
    .toISOString()
    .slice(0, 10);

  const temporaryIncomePattern =
    /maternity|paternity|parental|adoption|sick|sabbatical|career break|unpaid|temporary|reduced|leave/i;

  const temporaryEnd = (event: PayEventForPlan) =>
    event.maternity_leave_end || event.effective_until || null;

  const isTemporaryIncomeEvent = (event: PayEventForPlan) =>
    Boolean(temporaryEnd(event)) &&
    temporaryIncomePattern.test(
      `${String(event.pay_kind || "")} ${String(event.label || "")}`,
    );

  const activeInCurrentMonth = (event: PayEventForPlan) => {
    const starts = event.effective_from || "1900-01-01";
    const ends = temporaryEnd(event) || event.effective_until || "9999-12-31";
    return starts <= monthEndDate && ends >= monthStartDate;
  };

  const activeTemporaryPayEvents = payEventRows.filter(
    (event) => activeInCurrentMonth(event) && isTemporaryIncomeEvent(event),
  );

  function stableSalaryFallback(event: PayEventForPlan) {
    if (!event.person_id) return null;
    const targetTime = Date.parse(
      `${temporaryEnd(event) || event.effective_from || monthStartDate}T12:00:00Z`,
    );

    return (
      payEventRows
        .filter(
          (candidate) =>
            candidate.id !== event.id &&
            candidate.person_id === event.person_id &&
            !isTemporaryIncomeEvent(candidate) &&
            Number(candidate.gross_annual_salary || 0) > 0,
        )
        .sort((a, b) => {
          const aTime = Date.parse(`${a.effective_from || monthStartDate}T12:00:00Z`);
          const bTime = Date.parse(`${b.effective_from || monthStartDate}T12:00:00Z`);
          return Math.abs(aTime - targetTime) - Math.abs(bTime - targetTime);
        })[0] ?? null
    );
  }

  const normalSalaryPayEvents = payEventRows.map((event) => {
    const maternityLike = /maternity/i.test(
      `${String(event.pay_kind || "")} ${String(event.label || "")}`,
    );
    const fallback =
      activeInCurrentMonth(event) && isTemporaryIncomeEvent(event)
        ? stableSalaryFallback(event)
        : null;

    if (!maternityLike && !fallback) return event;

    const source = fallback ?? event;
    return {
      ...event,
      label: source.label,
      pay_kind: "salary",
      gross_annual_salary: source.gross_annual_salary,
      monthly_take_home_override: source.monthly_take_home_override,
      pension_percent: source.pension_percent,
      pension_method: source.pension_method,
      student_loan_plan: source.student_loan_plan,
      maternity_scheme: null,
      maternity_leave_start: null,
      maternity_leave_end: null,
      maternity_pay_mode: null,
      maternity_full_pay_weeks: null,
      maternity_half_pay_weeks: null,
      maternity_smp_only_weeks: null,
      maternity_unpaid_weeks: null,
      maternity_smp_weekly_rate: null,
    } satisfies PayEventForPlan;
  });

  const normalMonthPlan = buildMonthPlan({
    month: monthKey,
    profile: (profile as FinancialProfile | null) ?? null,
    categories: (categories ?? []) as SpendingCategoryForPlan[],
    childCosts: (childCosts ?? []) as ChildCostForPlan[],
    payEvents: normalSalaryPayEvents,
    mortgageDeals: ((deals ?? []) as HomeMortgageDeal[]).map((deal) => ({
      id: deal.id,
      lender: deal.lender,
      balance: deal.balance,
      interest_rate: deal.interest_rate,
      term_years: deal.term_years,
      monthly_payment_override: deal.monthly_payment_override,
      start_date: deal.start_date,
      end_date: deal.end_date,
    })) as HomeMortgageDealForPlan[],
    plannedItems: (plannedItems ?? []) as PlannedItemForPlan[],
    incomeEntries: (incomeEntries ?? []) as IncomeEntryForPlan[],
    peopleById,
  });

  function activePayRows(rows: PayEventForPlan[]) {
    const latestByPerson = new Map<string, PayEventForPlan>();
    rows
      .filter(activeInCurrentMonth)
      .sort((a, b) => String(a.effective_from).localeCompare(String(b.effective_from)))
      .forEach((event) => {
        latestByPerson.set(event.person_id ?? event.id, event);
      });
    return Array.from(latestByPerson.values());
  }

  const currentGrossHouseholdIncome = activePayRows(payEventRows).reduce(
    (sum, event) => sum + Number(event.gross_annual_salary || 0),
    0,
  );
  const normalGrossHouseholdIncome = activePayRows(normalSalaryPayEvents).reduce(
    (sum, event) => sum + Number(event.gross_annual_salary || 0),
    0,
  );

  const hasTemporaryIncomeDifference =
    activeTemporaryPayEvents.length > 0 &&
    Math.abs(Number(monthPlan.income || 0) - Number(normalMonthPlan.income || 0)) > 1;

  const temporaryIncomeContext = hasTemporaryIncomeDifference
    ? {
        label: Array.from(
          new Set(
            activeTemporaryPayEvents.map(
              (event) => event.label || event.pay_kind || "Temporary income change",
            ),
          ),
        ).join(" + "),
        endDate:
          activeTemporaryPayEvents
            .map(temporaryEnd)
            .filter((value): value is string => Boolean(value))
            .sort()
            .reverse()[0] ?? null,
      }
    : null;
'''
    text = regex_once(text, pattern, replacement, 'HousePage temporary-income block')

    text = replace_once(
        text,
        '''        normalMonthPlan={normalMonthPlan}\n        emergencySavings={(savingsAccounts ?? []).reduce(''',
        '''        normalMonthPlan={normalMonthPlan}\n        temporaryIncomeContext={temporaryIncomeContext}\n        currentGrossHouseholdIncome={currentGrossHouseholdIncome}\n        normalGrossHouseholdIncome={normalGrossHouseholdIncome}\n        emergencySavings={(savingsAccounts ?? []).reduce(''',
        'HousePage props',
    )
    backup(path)
    path.write_text(text)
    print('Patched', path.relative_to(repo))


def patch_unified(repo: Path):
    path = repo / 'loop_work/components/mortgage/HouseUnifiedWorkspace.tsx'
    text = path.read_text()

    anchor = 'import { MortgageOverpaymentPlanner } from "@/components/mortgage/MortgageOverpaymentPlanner";'
    if 'AffordabilityPlanningPanel' not in text:
        text = replace_once(
            text,
            anchor,
            anchor + '\nimport { AffordabilityPlanningPanel } from "@/components/mortgage/AffordabilityPlanningPanel";',
            'Unified affordability import',
        )

    text = text.replace('import { addAffordabilityScenario } from "@/app/affordability/actions";\n', '', 1)

    text = replace_once(
        text,
        '''  monthPlan: MonthPlan;\n  normalMonthPlan: MonthPlan;\n  emergencySavings: number;''',
        '''  monthPlan: MonthPlan;\n  normalMonthPlan: MonthPlan;\n  temporaryIncomeContext: { label: string; endDate: string | null } | null;\n  currentGrossHouseholdIncome: number;\n  normalGrossHouseholdIncome: number;\n  emergencySavings: number;''',
        'Unified props',
    )

    text = replace_once(
        text,
        '''  const affordability = useMemo(\n    () =>\n      buildHouseAffordabilityScore({\n        monthPlan: props.normalMonthPlan,\n        mortgagePayment: mortgage.payment,\n        mortgageBalance: mortgage.balance,\n        propertyValue: value.mid,\n        emergencySavings: props.emergencySavings,\n      }),\n    [props.normalMonthPlan, props.emergencySavings, mortgage.payment, mortgage.balance, value.mid],\n  );\n''',
        '''  const currentAffordability = useMemo(\n    () =>\n      buildHouseAffordabilityScore({\n        monthPlan: props.monthPlan,\n        mortgagePayment: mortgage.payment,\n        mortgageBalance: mortgage.balance,\n        propertyValue: value.mid,\n        emergencySavings: props.emergencySavings,\n      }),\n    [props.monthPlan, props.emergencySavings, mortgage.payment, mortgage.balance, value.mid],\n  );\n  const normalAffordability = useMemo(\n    () =>\n      buildHouseAffordabilityScore({\n        monthPlan: props.normalMonthPlan,\n        mortgagePayment: mortgage.payment,\n        mortgageBalance: mortgage.balance,\n        propertyValue: value.mid,\n        emergencySavings: props.emergencySavings,\n      }),\n    [props.normalMonthPlan, props.emergencySavings, mortgage.payment, mortgage.balance, value.mid],\n  );\n  const hasTemporaryIncome =\n    Boolean(props.temporaryIncomeContext) &&\n    Math.abs(Number(props.monthPlan.income || 0) - Number(props.normalMonthPlan.income || 0)) > 1;\n''',
        'Unified affordability calculations',
    )

    annual = '''  const annualGross = props.payEvents.reduce(\n    (sum, event) => sum + Number(event.gross_annual_salary || 0),\n    0,\n  );\n'''
    text = text.replace(annual, '', 1)

    text = replace_once(
        text,
        '''<button onClick={() => choose("affordability")} className="rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:border-violet-300 hover:shadow-md lg:min-h-[122px] lg:p-5"><p className="text-[10px] font-bold uppercase text-slate-400">Affordability</p><p className="mt-2 text-2xl font-bold">{affordability.score}/100</p><p className="mt-1 text-[11px] font-semibold text-slate-500">{affordability.label} · <span className="text-violet-700">View planning →</span></p></button>''',
        '''<button onClick={() => choose("affordability")} className="rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:border-violet-300 hover:shadow-md lg:min-h-[122px] lg:p-5"><p className="text-[10px] font-bold uppercase text-slate-400">Affordability</p><p className="mt-2 text-2xl font-bold">{currentAffordability.score}/100</p><p className="mt-1 text-[11px] font-semibold text-slate-500">{currentAffordability.label}{hasTemporaryIncome ? ` · normal ${normalAffordability.score}/100` : ""} · <span className="text-violet-700">View planning →</span></p></button>''',
        'Unified overview affordability card',
    )

    text = replace_once(
        text,
        '''<button onClick={() => choose("affordability")} className={`absolute right-4 top-4 rounded-2xl p-4 text-left shadow-lg ring-1 transition hover:scale-[1.02] ${affordability.tone}`}><p className="text-[10px] font-bold uppercase">Affordability</p><p className="text-3xl font-bold">{affordability.score}/100</p><p className="text-[11px] font-semibold">{affordability.label} · Open →</p></button>''',
        '''<button onClick={() => choose("affordability")} className={`absolute right-4 top-4 rounded-2xl p-4 text-left shadow-lg ring-1 transition hover:scale-[1.02] ${currentAffordability.tone}`}><p className="text-[10px] font-bold uppercase">Affordability</p><p className="text-3xl font-bold">{currentAffordability.score}/100</p><p className="text-[11px] font-semibold">{currentAffordability.label}{hasTemporaryIncome ? ` · normal ${normalAffordability.score}/100` : ""} · Open →</p></button>''',
        'Unified map affordability badge',
    )

    pattern = r'''          \{tab === "affordability" \? \([\s\S]*?          \) : null\}\n\n          \{tab === "overpayments"'''
    replacement = '''          {tab === "affordability" ? (\n            <div className="mx-auto max-w-[1460px]">\n              <AffordabilityPlanningPanel\n                currentScore={currentAffordability}\n                normalScore={normalAffordability}\n                hasTemporaryIncome={hasTemporaryIncome}\n                temporaryIncomeContext={props.temporaryIncomeContext}\n                currentMonthlyNetIncome={Number(props.monthPlan.income || 0)}\n                normalMonthlyNetIncome={Number(props.normalMonthPlan.income || 0)}\n                currentGrossHouseholdIncome={props.currentGrossHouseholdIncome}\n                normalGrossHouseholdIncome={props.normalGrossHouseholdIncome}\n                propertyValue={value.mid}\n                mortgageBalance={mortgage.balance}\n                fixedExMortgage={fixedExMortgage}\n                childMonthly={childMonthly}\n                interestRate={Number(benchmark?.rate_percent || deal?.interest_rate || 4.75)}\n                termYears={Number(deal?.term_years || 30)}\n              />\n            </div>\n          ) : null}\n\n          {tab === "overpayments"'''
    text = regex_once(text, pattern, replacement, 'Unified affordability tab')

    backup(path)
    path.write_text(text)
    print('Patched', path.relative_to(repo))


def patch_rates_overview(repo: Path):
    path = repo / 'loop_work/components/mortgage/HouseWorkspaceOverview.tsx'
    text = path.read_text()

    text = replace_once(text, 'import { useMemo, useState } from "react";', 'import { useEffect, useMemo, useState } from "react";', 'Rates React import')
    text = replace_once(text, 'import { MortgageQuoteIntake } from "@/components/mortgage/MortgageQuoteIntake";', 'import { MortgageQuoteIntake, type UserMortgageQuote } from "@/components/mortgage/MortgageQuoteIntake";', 'Rates quote import')

    text = replace_once(
        text,
        '''  const currentDeal =\n    deals.find((deal) => deal.home_id === currentHome?.id) ?? deals[0];\n\n''',
        '''  const currentDeal =\n    deals.find((deal) => deal.home_id === currentHome?.id) ?? deals[0];\n\n  const [userQuote, setUserQuote] = useState<UserMortgageQuote | null>(null);\n\n  useEffect(() => {\n    const homeId = currentHome?.id;\n    if (!homeId) {\n      setUserQuote(null);\n      return;\n    }\n\n    let cancelled = false;\n    fetch(`/api/house/mortgage/user-quotes?homeId=${encodeURIComponent(homeId)}`, { cache: "no-store" })\n      .then(async (response) => {\n        const data = await response.json();\n        if (!response.ok) throw new Error(data?.error || "Could not load saved quote");\n        if (!cancelled) setUserQuote((data?.quote as UserMortgageQuote | null) ?? null);\n      })\n      .catch(() => {\n        if (!cancelled) setUserQuote(null);\n      });\n\n    return () => { cancelled = true; };\n  }, [currentHome?.id]);\n\n''',
        'Rates user quote state',
    )

    text = replace_once(
        text,
        '''  const quoteDelta =\n    summary.quotePayment > 0\n      ? summary.quotePayment - summary.currentPayment\n      : null;\n\n  const currentTwoYearCost = summary.currentPayment * 24;\n  const loopTwoYearCost = summary.loopPayment * 24;\n  const quoteTwoYearCost = summary.quotePayment * 24 + summary.quoteFee;\n''',
        '''  const quoteDelta =\n    summary.quotePayment > 0\n      ? summary.quotePayment - summary.currentPayment\n      : null;\n\n  const remainingYearsForUserQuote = Math.max(1 / 12, summary.remainingMonths / 12);\n  const userQuotePayment =\n    userQuote && Number(userQuote.rate_percent || 0) > 0\n      ? monthlyPayment(summary.balance, Number(userQuote.rate_percent), remainingYearsForUserQuote)\n      : 0;\n  const userQuoteDelta =\n    userQuotePayment > 0 ? userQuotePayment - summary.currentPayment : null;\n\n  const currentTwoYearCost = summary.currentPayment * 24;\n  const loopTwoYearCost = summary.loopPayment * 24;\n  const quoteTwoYearCost = summary.quotePayment * 24 + summary.quoteFee;\n  const userQuoteTwoYearCost = userQuotePayment * 24 + Number(userQuote?.fee_amount || 0);\n''',
        'Rates user quote calculations',
    )

    text = replace_once(
        text,
        '''  const bestSaving = Math.max(\n    0,\n    currentTwoYearCost -\n      Math.min(\n        loopTwoYearCost || currentTwoYearCost,\n        quoteTwoYearCost || currentTwoYearCost,\n      ),\n  );\n''',
        '''  const comparableTwoYearCosts = [\n    loopTwoYearCost || null,\n    quoteTwoYearCost || null,\n    userQuoteTwoYearCost || null,\n  ].filter((value): value is number => value !== null && value > 0);\n\n  const bestSaving = Math.max(\n    0,\n    currentTwoYearCost -\n      (comparableTwoYearCosts.length ? Math.min(...comparableTwoYearCosts) : currentTwoYearCost),\n  );\n\n  const comparisonDeltas = [loopDelta, quoteDelta, userQuoteDelta].filter(\n    (value): value is number => value !== null,\n  );\n  const bestMonthlyDelta = comparisonDeltas.length ? Math.min(...comparisonDeltas) : null;\n''',
        'Rates best comparison',
    )

    text = replace_once(text,
        '          <section className="-mx-3 flex snap-x snap-mandatory gap-3 overflow-x-auto px-3 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden md:mx-0 md:grid md:grid-cols-3 md:overflow-visible md:px-0 md:pb-0">',
        '          <section className={`-mx-3 flex snap-x snap-mandatory gap-3 overflow-x-auto px-3 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden md:mx-0 md:grid md:overflow-visible md:px-0 md:pb-0 ${userQuote ? "md:grid-cols-2 xl:grid-cols-4" : "md:grid-cols-3"}`}>',
        'Rates scenario grid')

    best_card = '''            <ScenarioCard\n              eyebrow="Best sourced deal"\n              title={`${summary.quoteLender} · ${summary.quoteProduct}`}\n              rate={summary.quoteRate}\n              payment={summary.quotePayment}\n              helper={\n                summary.quoteFee > 0\n                  ? `${money(summary.quoteFee)} product fee`\n                  : "No product fee recorded"\n              }\n              delta={quoteDelta}\n              tone="quote"\n            />\n'''
    text = replace_once(text, best_card, best_card + '''\n            {userQuote ? (\n              <ScenarioCard\n                eyebrow="Your lender quote"\n                title={`${userQuote.lender_name}${userQuote.product_name ? ` · ${userQuote.product_name}` : ""}`}\n                rate={Number(userQuote.rate_percent)}\n                payment={userQuotePayment}\n                helper={`User supplied / indicative${userQuote.fee_amount != null ? ` · ${money(Number(userQuote.fee_amount))} fee` : ""}`}\n                delta={userQuoteDelta}\n                tone="quote"\n              />\n            ) : null}\n''', 'Rates user quote card')

    text = replace_once(text,
        '          <MortgageQuoteIntake currentHome={currentHome} currentDeal={currentDeal} />',
        '''          <MortgageQuoteIntake\n            currentHome={currentHome}\n            currentDeal={currentDeal}\n            existingQuote={userQuote}\n            onQuoteSaved={setUserQuote}\n            onQuoteRemoved={() => setUserQuote(null)}\n          />''',
        'Rates quote intake props')

    text = replace_once(text, '                      <th>Best sourced</th>', '                      <th>Best sourced</th>\n                      <th>Your quote</th>', 'Rates table header')

    text = replace_once(text,
        '''                      <td>\n                        {summary.quotePayment ? money(summary.quotePayment) : "—"}\n                      </td>\n                    </tr>''',
        '''                      <td>\n                        {summary.quotePayment ? money(summary.quotePayment) : "—"}\n                      </td>\n                      <td>{userQuotePayment ? money(userQuotePayment) : "—"}</td>\n                    </tr>''',
        'Rates monthly payment row')

    monthly_old = '''                      <td\n                        className={\n                          quoteDelta !== null && quoteDelta < 0\n                            ? "text-emerald-700"\n                            : ""\n                        }\n                      >\n                        {quoteDelta === null\n                          ? "—"\n                          : `${quoteDelta < 0 ? "−" : "+"}${money(\n                              Math.abs(quoteDelta),\n                            )}`}\n                      </td>\n                    </tr>'''
    monthly_new = monthly_old[:-len('                    </tr>')] + '''                      <td\n                        className={\n                          userQuoteDelta !== null && userQuoteDelta < 0\n                            ? "text-emerald-700"\n                            : ""\n                        }\n                      >\n                        {userQuoteDelta === null\n                          ? "—"\n                          : `${userQuoteDelta < 0 ? "−" : "+"}${money(Math.abs(userQuoteDelta))}`}\n                      </td>\n                    </tr>'''
    text = replace_once(text, monthly_old, monthly_new, 'Rates monthly delta row')

    text = replace_once(text,
        '''                      <td>\n                        {summary.quotePayment ? money(quoteTwoYearCost) : "—"}\n                      </td>\n                    </tr>''',
        '''                      <td>\n                        {summary.quotePayment ? money(quoteTwoYearCost) : "—"}\n                      </td>\n                      <td>{userQuotePayment ? money(userQuoteTwoYearCost) : "—"}</td>\n                    </tr>''',
        'Rates total row')

    text = replace_once(text,
        '''                      <td>{money(summary.quoteFee)}</td>\n                    </tr>''',
        '''                      <td>{money(summary.quoteFee)}</td>\n                      <td>{userQuote?.fee_amount == null ? "—" : money(Number(userQuote.fee_amount))}</td>\n                    </tr>''',
        'Rates fee row')

    text = replace_once(text,
        '''                {quoteDelta !== null && quoteDelta < 0\n                  ? `${money(Math.abs(quoteDelta))} less`\n                  : bestSaving > 0\n                    ? `${money(bestSaving)} saved`\n                    : "Compare now"}''',
        '''                {bestMonthlyDelta !== null && bestMonthlyDelta < 0\n                  ? `${money(Math.abs(bestMonthlyDelta))} less`\n                  : bestSaving > 0\n                    ? `${money(bestSaving)} saved`\n                    : "Compare now"}''',
        'Rates best display')

    text = replace_once(text,
        '''                {quoteDelta !== null && quoteDelta < 0\n                  ? "each month versus your current stored mortgage"\n                  : "Open the full workspace to inspect eligibility, fees and alternatives."}''',
        '''                {bestMonthlyDelta !== null && bestMonthlyDelta < 0\n                  ? "each month versus your current stored mortgage, using the best available comparison including your supplied quote"\n                  : "Inspect eligibility, fees, your supplied lender quote and alternatives before acting."}''',
        'Rates best copy')

    backup(path)
    path.write_text(text)
    print('Patched', path.relative_to(repo))


def patch_image_route(repo: Path):
    path = repo / 'loop_work/app/api/house/mortgage/import-product-image/route.ts'
    text = path.read_text()
    text = replace_once(text,
        '''  const secret = await getActiveIntegrationSecret(supabase, user.id, "openai");\n  if (!secret?.value) return NextResponse.json({ error: "Image reading is unavailable. Use URL or Manual." }, { status: 503 });\n  const budget = await checkAiRouteAllowed(supabase, user.id, "mortgage_product_import");''',
        '''  const secret = await getActiveIntegrationSecret(supabase, user.id, "openai");\n  const apiKey = secret?.value || process.env.OPENAI_API_KEY;\n  if (!apiKey) return NextResponse.json({ error: "Image reading is unavailable. Use URL or Manual." }, { status: 503 });\n  const budget = await checkAiRouteAllowed(supabase, user.id, "mortgage_product_import");''',
        'Image API key fallback')
    text = replace_once(text,
        'headers: { Authorization: `Bearer ${secret.value}`, "Content-Type": "application/json" },',
        'headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },',
        'Image auth header')
    backup(path)
    path.write_text(text)
    print('Patched', path.relative_to(repo))


def copy_files(repo: Path):
    for src in FILES.rglob('*'):
        if not src.is_file():
            continue
        rel = src.relative_to(FILES)
        dest = repo / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            backup(dest)
        shutil.copy2(src, dest)
        print('Installed', rel)


def main():
    repo = repo_root(Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd())
    print('Applying LOOP House affordability + lender quote v3 to', repo)
    patch_house_page(repo)
    patch_unified(repo)
    patch_rates_overview(repo)
    patch_image_route(repo)
    copy_files(repo)
    print('Done. Run git diff --check, npm run build, and git status --short. Backups end in .housev3.bak; do not add them.')


if __name__ == '__main__':
    main()
