# Validation checklist

1. Affordability with no temporary income
   - one score only
   - label says Current affordability
   - each criterion expands

2. Maternity / temporary pay with a known end date
   - Right now score is shown
   - After temporary change score is shown
   - both monthly net income values are visible
   - scenario form shows both income bases

3. Permanent pay change / no end date
   - no artificial second score is shown

4. Manual lender quote
   - Max LTV starts blank
   - Rate type can be selected
   - Use this quote saves
   - saved quote appears as its own comparison card
   - cost table includes Your quote
   - Edit and Remove work

5. Image lender quote
   - upload works without requiring a user-owned OpenAI key when the platform key exists
   - extracted fields remain editable
   - nothing is added until Use this quote is pressed

6. URL lender quote
   - extracted fields remain editable
   - Use this quote persists household-specific data

7. Data separation
   - `user_mortgage_quotes` receives the quote
   - `mortgage_rate_deals` is untouched

8. Quality
   - `git diff --check` is blank
   - no `<<<<<<<`, `=======`, `>>>>>>>` conflict markers
