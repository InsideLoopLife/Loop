# LOOP House affordability + lender quote v3

This patch contains the two changes reviewed on 19 Aug 2026:

## Affordability
- Uses the actual current household month plan for the headline score.
- Keeps a separate normal/underlying score where LOOP can identify a temporary income event with an end date.
- Handles maternity first, and also recognises temporary leave/reduced-pay patterns when a normal salary event is available for the same person.
- Shows current vs normal household net income.
- Expands every affordability criterion with:
  - what it means
  - how LOOP scores it
  - what improves it
- Keeps the move scenario editable and adds an income-basis selector when a temporary income change is active.
- Fixes the misleading `Current affordability` label when the old screen was actually using the normalised income plan.

## Lender quotes
- Manual, URL and Image all end in a review step and a real **Use this quote** action.
- User-supplied quotes are stored separately in `user_mortgage_quotes`.
- They never enter the central mortgage-rate catalogue.
- The saved quote becomes a fourth comparison card and a fourth column in the cost table.
- Edit / Remove are available.
- Max LTV is optional rather than defaulting to 0%.
- Image quote extraction can use the platform `OPENAI_API_KEY` if the user has not connected their own OpenAI integration.
- The mortgage-product AI entitlement route has been added for the configured tiers.

## Supabase
The production Supabase project has already been updated with:
- `user_mortgage_quotes` + RLS
- `mortgage_product_import` AI route/tier configuration

The migration SQL files are included so Git remains the source of truth.

## Apply

```bash
cd /workspaces/Loop

unzip -o /workspaces/Loop/loop_work/loop-house-affordability-quotes-v3.zip   -d /tmp/loop-house-affordability-quotes-v3

python   /tmp/loop-house-affordability-quotes-v3/loop-house-affordability-quotes-v3/apply_fix.py   /workspaces/Loop

cd /workspaces/Loop/loop_work

git diff --check
git status --short
npm run build
```

If the ZIP is downloaded somewhere else, use the real path printed by:

```bash
find /workspaces/Loop -maxdepth 3 -name 'loop-house-affordability-quotes-v3.zip' -print
```

## Stage

```bash
git add   domains/wealth/house/HousePage.tsx   components/mortgage/HouseUnifiedWorkspace.tsx   components/mortgage/HouseWorkspaceOverview.tsx   components/mortgage/AffordabilityPlanningPanel.tsx   components/mortgage/MortgageQuoteIntake.tsx   lib/wealth/house-snapshot.ts   app/api/house/mortgage/import-product-image/route.ts   app/api/house/mortgage/user-quotes/route.ts   supabase/migrations/202608190400_user_mortgage_quotes.sql   supabase/migrations/202608190401_mortgage_product_import_ai_route.sql

git diff --cached --check
git status
```

Backups created by the patcher end in `.housev3.bak`; do not stage them.

Suggested commit:

```bash
git commit -m "Improve affordability context and lender quote comparisons"
git push origin main
```
