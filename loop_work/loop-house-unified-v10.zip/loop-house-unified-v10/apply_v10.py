from pathlib import Path

p = Path('domains/wealth/house/HousePage.tsx')
t = p.read_text()
if 'HouseUnifiedWorkspace' not in t:
    t = t.replace(
        'import { WealthRouteSkeleton } from "@/components/loading/WealthRouteSkeleton";',
        'import { WealthRouteSkeleton } from "@/components/loading/WealthRouteSkeleton";\nimport { HouseUnifiedWorkspace } from "@/components/mortgage/HouseUnifiedWorkspace";'
    )
old = '''<MortgagePlannerClient
        scenarios={scenarios ?? []}
        people={peopleRows}
        homes={homes ?? []}
        owners={normalisedOwners}
        deals={deals ?? []}
        valuations={valuations ?? []}
        monthPlan={monthPlan}
        normalMonthPlan={normalMonthPlan}
        emergencySavings={(savingsAccounts ?? []).reduce(
          (sum: number, account: any) =>
            sum + Number(account.current_balance || 0),
          0,
        )}
        childProfileCount={childProfileCount}
        renewalRecommendations={renewalRecommendations ?? []}
        marketDeals={marketDeals ?? []}
        moveQueries={moveQueries ?? []}
        liabilityAllocations={liabilityAllocations ?? []}
        dealPreferences={dealPreferences ?? []}
        workspacePreference={workspacePreference ?? null}
        boeBenchmarks={boeBenchmarks ?? []}
        svrKnowledge={svrKnowledge ?? []}
      />'''
new = '''<HouseUnifiedWorkspace
        homes={homes ?? []}
        owners={normalisedOwners}
        people={peopleRows}
        deals={deals ?? []}
        valuations={valuations ?? []}
        liabilityAllocations={liabilityAllocations ?? []}
        moveQueries={moveQueries ?? []}
        renewalRecommendations={renewalRecommendations ?? []}
        marketDeals={marketDeals ?? []}
        boeBenchmarks={boeBenchmarks ?? []}
        monthPlan={monthPlan}
        normalMonthPlan={normalMonthPlan}
        emergencySavings={(savingsAccounts ?? []).reduce(
          (sum: number, account: any) => sum + Number(account.current_balance || 0),
          0,
        )}
        categories={(categories ?? []) as SpendingCategoryForPlan[]}
        payEvents={(payEvents ?? []) as PayEventForPlan[]}
      />'''
if old not in t:
    raise SystemExit('Could not find legacy MortgagePlannerClient invocation in HousePage.tsx')
t = t.replace(old, new)
p.write_text(t)

Path('app/mortgage/page.tsx').write_text('export { default } from "@/domains/wealth/house/HousePage";\n')

redirects = {
    'app/mortgage/property/page.tsx': 'property',
    'app/mortgage/rates/page.tsx': 'rates',
    'app/mortgage/moving-costs/page.tsx': 'moving',
    'app/mortgage/advanced/page.tsx': 'overview',
    'app/affordability/page.tsx': 'affordability',
}
for path, tab in redirects.items():
    pp = Path(path)
    pp.parent.mkdir(parents=True, exist_ok=True)
    target = '/mortgage' if tab == 'overview' else f'/mortgage?tab={tab}'
    pp.write_text(
        'import { redirect } from "next/navigation";\n'
        f'export default function RetiredHouseRoute() {{ redirect("{target}"); }}\n'
    )

p = Path('components/mortgage/HouseWorkspaceOverview.tsx')
t = p.read_text()
if 'calculateProjectedMortgageBalance' not in t:
    t = t.replace(
        'import { calculateMonthlyMortgagePayment } from "@/lib/calculations/mortgage";',
        'import { calculateMonthlyMortgagePayment, calculateProjectedMortgageBalance } from "@/lib/calculations/mortgage";'
    )
t = t.replace(
    'const balance = Number(currentDeal?.balance || 0);',
    '''const balance = currentDeal
      ? calculateProjectedMortgageBalance({
          openingBalance: Number(currentDeal.balance || 0),
          annualInterestRate: Number(currentDeal.interest_rate || 0),
          termYears: Number(currentDeal.term_years || 25),
          balanceAsOfDate: currentDeal.balance_as_of_date ?? currentDeal.start_date,
          asOfDate: new Date(),
          monthlyPayment: currentDeal.monthly_payment_override,
          repaymentType: currentDeal.repayment_type ?? "repayment",
        }).projectedBalance
      : 0;'''
)
t = t.replace('href="/mortgage/advanced"', 'href="/mortgage?tab=rates"')
p.write_text(t)
