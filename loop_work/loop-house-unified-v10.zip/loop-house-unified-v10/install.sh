#!/usr/bin/env bash
set -euo pipefail
cd /workspaces/Loop/loop_work
SRC="/tmp/loop-house-unified-v10/loop-house-unified-v10"
mkdir -p ./lib/wealth
cp -f "$SRC/house-snapshot.ts" ./lib/wealth/house-snapshot.ts
cp -f "$SRC/HouseUnifiedWorkspace.tsx" ./components/mortgage/HouseUnifiedWorkspace.tsx
cp -f "$SRC/loading.tsx" ./app/mortgage/loading.tsx
python "$SRC/apply_v10.py"
npm run typecheck
cd /workspaces/Loop
git add \
  loop_work/lib/wealth/house-snapshot.ts \
  loop_work/components/mortgage/HouseUnifiedWorkspace.tsx \
  loop_work/components/mortgage/HouseWorkspaceOverview.tsx \
  loop_work/domains/wealth/house/HousePage.tsx \
  loop_work/app/mortgage/page.tsx \
  loop_work/app/mortgage/loading.tsx \
  loop_work/app/mortgage/property/page.tsx \
  loop_work/app/mortgage/rates/page.tsx \
  loop_work/app/mortgage/moving-costs/page.tsx \
  loop_work/app/mortgage/advanced/page.tsx \
  loop_work/app/affordability/page.tsx
git diff --cached --check
git commit -m "Unify House workspace and retire legacy UI"
git push origin main
