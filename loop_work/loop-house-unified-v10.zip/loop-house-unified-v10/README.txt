LOOP House Unified v10

Core change
- /mortgage becomes one unified client-side House workspace.
- Overview, Property, Mortgage & rates, Affordability and Moving home switch instantly after the first payload loads.
- The old House workspace is no longer user-facing.
- Old URLs redirect into the relevant unified tab.

Logic retained/restored
- Mortgage balance is projected to today from balance_as_of_date, payment, rate, term and repayment type.
- Home overview restores the tighter map, valuation range, current mortgage/payment, equity/LTV and affordability score.
- BoE Bank Rate and nearest LTV mortgage benchmark remain visible.
- Rates comparison uses projected current balance.
- Affordability pre-fills known values and leaves them editable.
- Current mortgage is excluded from the fixed/debt input in affordability.

Editing in the new format
- Add/edit/delete property via HomeWizard modal.
- Add/edit/delete mortgage via MortgageWizard modal.
- Add/edit/delete valuation via ValuationWizard modal.
- Add move scenario via MoveQueryWizard modal.
- Save affordability scenario directly inside the unified Affordability tab.

Performance
- Tab changes are local React state, not Next route navigations, so they do not repeat Supabase queries.
- A first-load skeleton paints immediately.
- This keeps the existing parallel server loader initially; after deployment, instrumenting query timings can safely remove any remaining slow initial-load queries without weakening House logic.

Install
cd /workspaces/Loop/loop_work
unzip -o ./loop-house-unified-v10.zip -d /tmp/loop-house-unified-v10
chmod +x /tmp/loop-house-unified-v10/loop-house-unified-v10/install.sh
/tmp/loop-house-unified-v10/loop-house-unified-v10/install.sh
