from pathlib import Path

# Overview
p = Path("domains/wealth/house/HouseHomePage.tsx")
t = p.read_text().replace("font-black", "font-bold")
t = t.replace('text-4xl font-bold tracking-tight text-slate-950', 'text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl')
t = t.replace('className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"', 'className="grid grid-cols-2 gap-2 sm:gap-3 xl:grid-cols-4"', 1)
t = t.replace('className="relative min-h-[330px] overflow-hidden', 'className="relative min-h-[230px] overflow-hidden sm:min-h-[300px] lg:min-h-[330px]')
# lower cards 2x2, hide verbose copy on phone
t = t.replace('className="grid gap-3 md:grid-cols-2 xl:grid-cols-4"', 'className="grid grid-cols-2 gap-2 sm:gap-3 xl:grid-cols-4"', 1)
t = t.replace('className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm hover:border-violet-200"', 'className="min-w-0 rounded-2xl border border-slate-200 bg-white p-3.5 shadow-sm hover:border-violet-200 sm:p-5"')
t = t.replace('className="mt-2 min-h-[3rem] text-xs font-semibold leading-5 text-slate-500"', 'className="mt-2 hidden min-h-[3rem] text-xs font-semibold leading-5 text-slate-500 sm:block"')
p.write_text(t)

# Rates workspace
p = Path("components/mortgage/HouseWorkspaceOverview.tsx")
t = p.read_text().replace("font-black", "font-bold")
# stop nested width creating horizontal page overflow
t = t.replace('className="mx-auto w-[95vw] max-w-[1580px] px-4 py-6 sm:px-6 lg:px-8"', 'className="w-full min-w-0"')
# hide duplicate internal sidebar on all widths
t = t.replace('className="hidden lg:block"', 'className="hidden"', 1)
# collapse its old 2-column shell to a single content column
t = t.replace('className="grid gap-6 lg:grid-cols-[190px_minmax(0,1fr)]"', 'className="min-w-0"')
# scenario cards horizontal snap on mobile
t = t.replace('className="grid gap-3 md:grid-cols-3"', 'className="-mx-3 flex snap-x snap-mandatory gap-3 overflow-x-auto px-3 pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden md:mx-0 md:grid md:grid-cols-3 md:overflow-visible md:px-0 md:pb-0"', 1)
t = t.replace('className={`rounded-[1.4rem] border p-5 shadow-sm ${toneClass}`}', 'className={`w-[84vw] max-w-[390px] shrink-0 snap-center rounded-[1.4rem] border p-4 shadow-sm sm:p-5 md:w-auto md:max-w-none md:shrink ${toneClass}`}')
t = t.replace('className="mt-5 text-center text-sm font-bold text-slate-500"', 'className="mt-3 text-center text-sm font-bold text-slate-500 sm:mt-5"')
t = t.replace('className="mt-6 border-t border-slate-100 pt-5 text-center"', 'className="mt-4 border-t border-slate-100 pt-4 text-center sm:mt-6 sm:pt-5"')
# compact mobile hero
t = t.replace('text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl', 'text-2xl font-bold tracking-tight text-slate-950 sm:text-4xl')
p.write_text(t)

# Other House pages
for path in ["domains/wealth/house/HousePropertyPage.tsx","domains/wealth/house/HouseMovingCostsPage.tsx"]:
    p = Path(path)
    if p.exists():
        t = p.read_text().replace("font-black","font-bold")
        t = t.replace('text-4xl font-bold tracking-tight', 'text-3xl font-bold tracking-tight sm:text-4xl')
        t = t.replace('className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"', 'className="grid grid-cols-2 gap-2 sm:gap-3 xl:grid-cols-4"')
        p.write_text(t)

# Affordability
p = Path("app/affordability/page.tsx")
if p.exists():
    t = p.read_text().replace("font-black","font-bold")
    t = t.replace('text-4xl font-bold tracking-tight text-slate-950', 'text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl')
    t = t.replace('className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"', 'className="grid grid-cols-2 gap-2 sm:gap-3 xl:grid-cols-4"')
    p.write_text(t)
