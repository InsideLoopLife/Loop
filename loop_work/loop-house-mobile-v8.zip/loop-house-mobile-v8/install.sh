#!/usr/bin/env bash
set -euo pipefail
cd /workspaces/Loop/loop_work
SRC="/tmp/loop-house-mobile-v8/loop-house-mobile-v8"

cp -f "$SRC/HouseShell.tsx" ./components/mortgage/HouseShell.tsx
python "$SRC/apply_v8.py"

npm run typecheck

cd /workspaces/Loop
git add \
  loop_work/components/mortgage/HouseShell.tsx \
  loop_work/components/mortgage/HouseWorkspaceOverview.tsx \
  loop_work/domains/wealth/house/HouseHomePage.tsx \
  loop_work/domains/wealth/house/HousePropertyPage.tsx \
  loop_work/domains/wealth/house/HouseMovingCostsPage.tsx \
  loop_work/app/affordability/page.tsx

git diff --cached --check
git commit -m "Improve House mobile experience"
git push origin main
