LOOP House mobile v8

Focused on the screenshots:
- adds visible mobile House sub-navigation
- prevents horizontal overflow
- gives content bottom clearance for fixed LOOP nav
- Overview metrics become 2x2
- Overview action cards become compact 2x2
- shorter mobile map
- Rates scenarios become horizontal snap cards instead of a very long vertical stack
- removes the duplicate internal rates sidebar from the mobile/desktop nested workspace
- denser Property, Moving Costs and Affordability mobile layouts
- House routes prefetch immediately for quicker switching

Install:
cd /workspaces/Loop/loop_work
unzip -o ./loop-house-mobile-v8.zip -d /tmp/loop-house-mobile-v8
chmod +x /tmp/loop-house-mobile-v8/loop-house-mobile-v8/install.sh
/tmp/loop-house-mobile-v8/loop-house-mobile-v8/install.sh
