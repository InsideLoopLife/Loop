#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

BUNDLE_DIR = Path(__file__).resolve().parent
FILES_DIR = BUNDLE_DIR / "files"


def locate_repo(start: Path) -> Path:
    start = start.resolve()
    for candidate in (start, start.parent):
        if (candidate / "loop_work/components/Nav.tsx").exists():
            return candidate
        if candidate.name == "loop_work" and (candidate / "components/Nav.tsx").exists():
            return candidate.parent
    raise SystemExit(
        "Could not find LOOP repo. Run from /workspaces/Loop or "
        "/workspaces/Loop/loop_work, or pass the repo path as the first argument."
    )


def replace_once(text: str, pattern: str, replacement: str, label: str) -> str:
    updated, count = re.subn(pattern, replacement, text, count=1, flags=re.S)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one match, found {count}")
    return updated


def replace_literal_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old, new, 1)


def backup(path: Path) -> None:
    backup_path = path.with_suffix(path.suffix + ".navfix.bak")
    if not backup_path.exists():
        shutil.copy2(path, backup_path)


def patch_nav(path: Path) -> None:
    text = path.read_text()

    if "children?: NavChild[]" in text and "loop:wealth-feature-changed" in text:
        print(f"Already patched: {path.relative_to(REPO)}")
        return

    backup(path)

    types = r'''type FeatureGate = {
  feature?: keyof UserFeatureAccess;
  anyFeature?: Array<keyof UserFeatureAccess>;
};

type NavChild = FeatureGate & {
  href: string;
  label: string;
};

type NavLink = FeatureGate & {
  href: string;
  label: string;
  icon: React.ElementType;
  children?: NavChild[];
};'''

    text = replace_once(
        text,
        r'type NavLink = \{.*?\n\};(?=\n\nconst wealthLinks)',
        types,
        "Nav link types",
    )

    wealth_links = r'''const wealthLinks: NavLink[] = [
  {
    href: "/briefing",
    label: "Your LOOP",
    icon: Sparkles,
    feature: "aiFinancialBriefing",
  },
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  {
    href: "/financial-flow",
    label: "Financial Flow",
    icon: WalletCards,
    children: [
      { href: "/financial-flow", label: "Overview" },
      { href: "/accounts", label: "Accounts" },
      { href: "/financial-flow?tab=income", label: "Income" },
      { href: "/financial-flow?tab=spending", label: "Spending" },
      { href: "/financial-flow?tab=savings", label: "Savings & Pots" },
      { href: "/financial-flow?tab=loans", label: "Loans & Debt" },
    ],
  },
  {
    href: "/investments",
    label: "Pensions & Investments",
    icon: LineChart,
    anyFeature: ["investments", "pensions"],
    children: [
      { href: "/investments", label: "Overview" },
      {
        href: "/investments?view=pensions",
        label: "Pensions",
        feature: "pensions",
      },
      {
        href: "/investments?view=investments",
        label: "Investments",
        feature: "investments",
      },
      {
        href: "/retirement",
        label: "Retirement Planning",
        feature: "pensions",
      },
    ],
  },
  {
    href: "/mortgage",
    label: "House",
    icon: House,
    feature: "mortgage",
    children: [
      { href: "/mortgage", label: "Overview" },
      { href: "/house", label: "Property" },
      { href: "/affordability", label: "Affordability" },
      { href: "/affordability-lab", label: "Affordability Lab" },
    ],
  },
];'''

    text = replace_once(
        text,
        r'const wealthLinks: NavLink\[\] = \[.*?\n\];(?=\n\nconst healthLinks)',
        wealth_links,
        "Wealth navigation hierarchy",
    )

    fresh_bootstrap = r'''function loadNavigationBootstrap() {
  return fetch("/api/user/navigation-bootstrap", { cache: "no-store" })
    .then((response) =>
      response.ok ? (response.json() as Promise<NavigationBootstrap>) : null,
    )
    .catch(() => null);
}'''

    text = replace_once(
        text,
        r'let navigationBootstrapPromise: Promise<NavigationBootstrap \| null> \| null = null;\n\nfunction loadNavigationBootstrap\(\) \{.*?\n\}',
        fresh_bootstrap,
        "Navigation bootstrap cache",
    )

    text = replace_literal_once(
        text,
        '  "/investments": ["/investments", "/pensions"],',
        '  "/investments": ["/investments", "/pensions", "/retirement"],',
        "Investment route family",
    )

    text = replace_literal_once(
        text,
        "  siblings: NavLink[],",
        "  siblings: Array<{ href: string }>,",
        "Active-link sibling type",
    )

    text = replace_literal_once(
        text,
        "function canShow(link: NavLink, features: UserFeatureAccess) {",
        "function canShow(link: FeatureGate, features: UserFeatureAccess) {",
        "Feature-gate type",
    )

    nav_item = r'''function NavItem({
  link,
  active,
  side = false,
  onNavigate,
  onIntent,
}: {
  link: NavLink;
  active: boolean;
  side?: boolean;
  onNavigate?: () => void;
  onIntent?: (href: string) => void;
}) {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const Icon = link.icon;
  const children = link.children ?? [];
  const hasChildren = children.length > 0;

  const parentLink = (
    <Link
      href={link.href}
      prefetch
      onClick={onNavigate}
      onMouseEnter={() => onIntent?.(link.href)}
      onFocus={() => onIntent?.(link.href)}
      onTouchStart={() => onIntent?.(link.href)}
      className={
        side
          ? `group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-bold transition ${
              active
                ? "bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-950/25"
                : "text-slate-300 hover:bg-white/10 hover:text-white"
            }`
          : `group relative flex items-center gap-1.5 px-2.5 py-2 text-[13px] font-black transition ${
              active
                ? "text-slate-950 after:absolute after:inset-x-2 after:-bottom-0.5 after:h-0.5 after:rounded-full after:bg-slate-950"
                : "text-slate-500 hover:text-slate-950"
            }`
      }
    >
      <Icon className={side ? "h-[18px] w-[18px]" : "h-4 w-4"} />
      <span className={side ? "min-w-0 flex-1" : "hidden lg:inline"}>
        {link.label}
      </span>
      {hasChildren ? (
        <ChevronDown
          className={`${side ? "h-4 w-4" : "hidden h-3.5 w-3.5 lg:block"} shrink-0 transition group-hover:translate-y-0.5`}
          aria-hidden="true"
        />
      ) : null}
    </Link>
  );

  if (!hasChildren) return parentLink;

  if (side) {
    return (
      <div>
        {parentLink}
        <div className="ml-6 mt-1 space-y-1 border-l border-white/10 pl-3">
          {children.map((child) => {
            const childActive = isActiveLink(
              pathname,
              searchParams,
              child.href,
              children,
            );
            return (
              <Link
                key={child.href}
                href={child.href}
                prefetch
                onClick={onNavigate}
                onMouseEnter={() => onIntent?.(child.href)}
                onFocus={() => onIntent?.(child.href)}
                className={`block rounded-lg px-2.5 py-2 text-xs font-bold transition ${
                  childActive
                    ? "bg-white/12 text-white"
                    : "text-slate-400 hover:bg-white/8 hover:text-white"
                }`}
              >
                {child.label}
              </Link>
            );
          })}
        </div>
      </div>
    );
  }

  return (
    <div className="group relative">
      {parentLink}
      <div className="invisible pointer-events-none absolute left-1/2 top-full z-[80] w-64 -translate-x-1/2 pt-2 opacity-0 transition duration-150 group-hover:visible group-hover:pointer-events-auto group-hover:opacity-100 group-focus-within:visible group-focus-within:pointer-events-auto group-focus-within:opacity-100">
        <div className="overflow-hidden rounded-2xl border border-slate-200/80 bg-white p-2 shadow-[0_22px_70px_-25px_rgba(15,23,42,.45)] ring-1 ring-slate-950/5">
          {children.map((child) => {
            const childActive = isActiveLink(
              pathname,
              searchParams,
              child.href,
              children,
            );
            return (
              <Link
                key={child.href}
                href={child.href}
                prefetch
                onClick={onNavigate}
                onMouseEnter={() => onIntent?.(child.href)}
                onFocus={() => onIntent?.(child.href)}
                className={`block rounded-xl px-3 py-2.5 text-sm font-black transition ${
                  childActive
                    ? "bg-slate-950 text-white"
                    : "text-slate-700 hover:bg-slate-50 hover:text-slate-950"
                }`}
              >
                {child.label}
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}'''

    text = replace_once(
        text,
        r'function NavItem\(\{.*?\n\}(?=\n\nfunction LayoutButtons)',
        nav_item,
        "Dropdown-capable NavItem",
    )

    old_visible = '''  const visibleWealthLinks = useMemo(
    () => wealthLinks.filter((link) => canShow(link, features)),
    [features],
  );'''
    new_visible = '''  const visibleWealthLinks = useMemo(
    () =>
      wealthLinks
        .filter((link) => canShow(link, features))
        .map((link) => ({
          ...link,
          children: link.children?.filter((child) => canShow(child, features)),
        })),
    [features],
  );'''
    text = replace_literal_once(text, old_visible, new_visible, "Visible wealth links")

    feature_listener = r'''  useEffect(() => {
    const handleWealthFeatureChange = (event: Event) => {
      const next = (
        event as CustomEvent<{ features?: Partial<UserFeatureAccess> }>
      ).detail?.features;
      if (next) {
        setFeatures((current) => ({ ...current, ...next }));
      }
    };
    window.addEventListener(
      "loop:wealth-feature-changed",
      handleWealthFeatureChange,
    );
    return () =>
      window.removeEventListener(
        "loop:wealth-feature-changed",
        handleWealthFeatureChange,
      );
  }, []);

'''
    marker = '''  useEffect(() => {
    document.body.dataset.loopNav = layout;'''
    if marker not in text:
        raise RuntimeError("Wealth feature listener insertion point not found")
    text = text.replace(marker, feature_listener + marker, 1)

    path.write_text(text)
    print(f"Patched: {path.relative_to(REPO)}")


def patch_account_page(path: Path) -> None:
    text = path.read_text()
    client_import = 'import { WealthFeatureToggle } from "@/components/account/WealthFeatureToggle";'

    if client_import not in text:
        marker = 'import { NavigationLayoutSettings } from "@/components/account/NavigationLayoutSettings";'
        if marker not in text:
            raise RuntimeError("Account toggle import insertion point not found")
        text = text.replace(marker, marker + "\n" + client_import, 1)

    if "type WealthFeatureToggleProps = {" in text:
        text = replace_once(
            text,
            r'\n\ntype WealthFeatureToggleProps = \{.*?(?=\nexport default async function AccountPage)',
            "",
            "Old server-rendered WealthFeatureToggle",
        )

    backup(path)
    path.write_text(text)
    print(f"Patched: {path.relative_to(REPO)}")


def patch_investments_client(path: Path) -> None:
    text = path.read_text()

    if 'useRouter, useSearchParams' not in text:
        text = replace_literal_once(
            text,
            'import { useRouter } from "next/navigation";',
            'import { useRouter, useSearchParams } from "next/navigation";',
            "Investment search params import",
        )

    if 'const requestedView = searchParams.get("view");' not in text:
        marker = "  const router = useRouter();"
        if marker not in text:
            raise RuntimeError("Could not find investment router hook")

        addition = r'''  const router = useRouter();
  const searchParams = useSearchParams();
  const requestedView = searchParams.get("view");

  useEffect(() => {
    if (requestedView === "pensions") {
      setArea("pensions");
      setExperience("pension-command");
      return;
    }
    if (requestedView === "investments") {
      setArea("investments");
      setExperience("investment-command");
      return;
    }
    if (requestedView === "overview") {
      setExperience("overview");
    }
  }, [requestedView]);'''
        text = text.replace(marker, addition, 1)

    backup(path)
    path.write_text(text)
    print(f"Patched: {path.relative_to(REPO)}")


def copy_new_files() -> None:
    for source in FILES_DIR.rglob("*"):
        if not source.is_file():
            continue
        relative = source.relative_to(FILES_DIR)
        destination = REPO / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists():
            backup(destination)
        shutil.copy2(source, destination)
        print(f"Installed: {relative}")


def main() -> None:
    global REPO
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
    REPO = locate_repo(target)

    nav = REPO / "loop_work/components/Nav.tsx"
    account = REPO / "loop_work/domains/identity/account/AccountPage.tsx"
    investments = REPO / "loop_work/components/investments/PensionsInvestmentsClient.tsx"

    missing = [p for p in (nav, account, investments) if not p.exists()]
    if missing:
        raise SystemExit(
            "Missing expected LOOP files:\n" + "\n".join(f" - {p}" for p in missing)
        )

    print(f"Applying LOOP nav/account fix to: {REPO}")
    patch_nav(nav)
    patch_account_page(account)
    patch_investments_client(investments)
    copy_new_files()

    print("\nDone.")
    print("Next:")
    print("  cd loop_work")
    print("  npm run build")
    print("  git status")
    print("  git diff --check")
    print('  git add components/Nav.tsx components/account/WealthFeatureToggle.tsx \\')
    print('    app/api/user/wealth-settings/route.ts \\')
    print('    domains/identity/account/AccountPage.tsx \\')
    print('    components/investments/PensionsInvestmentsClient.tsx')
    print('  git commit -m "Restore nav dropdowns and autosave account toggles"')
    print("  git push origin main")


if __name__ == "__main__":
    main()
