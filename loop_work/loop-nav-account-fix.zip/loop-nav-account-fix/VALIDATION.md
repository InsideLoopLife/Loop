# Validation checklist

After deploy:

1. Top navigation
   - Hover Financial Flow; submenu opens and remains open while moving into it.
   - Test Accounts, Income, Spending, Savings & Pots, Loans & Debt.
   - Hover Pensions & Investments; test Pensions, Investments and Retirement Planning.
   - Hover House; test Property, Affordability and Affordability Lab.

2. Layout preference
   - Switch Top → Side from Account.
   - Hard reload.
   - Confirm Side remains selected.
   - Switch back to Top and repeat.

3. Account → Wealth toggles
   - Turn a module off.
   - It should show Saving… then Saved without pressing the bottom form button.
   - Relevant nav entry/child should update.
   - Hard reload and confirm the setting persisted.
   - Turn it back on.

4. Regression
   - Account modal opens.
   - Wealth/Health switch works.
   - Mobile navigation still renders.
   - `npm run build` succeeds.
