# LOOP navigation + Account toggle fix

This bundle restores the missing desktop navigation hierarchy and fixes the Account wealth-module toggles so they save as soon as they are changed.

## What changes

- **Financial Flow** dropdown: Overview, Accounts, Income, Spending, Savings & Pots, Loans & Debt.
- **Pensions & Investments** dropdown: Overview, Pensions, Investments, Retirement Planning.
- **House** dropdown: Overview, Property, Affordability, Affordability Lab.
- Side navigation gets the same nested hierarchy.
- Disabled features are still hidden through LOOP's existing feature access logic.
- Removes the stale module-global navigation bootstrap promise, so Top/Side changes are not overwritten by an old response.
- Account wealth toggles now auto-save immediately, show Saving/Saved/error state, and revert if a save fails.
- The live nav updates when those Account toggles change.
- Adds deep-link handling for `/investments?view=pensions` and `/investments?view=investments`.

The existing **Save wealth settings** button remains because the same form contains other wealth/home fields.

## Apply

From the LOOP Codespace:

```bash
unzip -o /path/to/loop-nav-account-fix.zip -d /tmp/loop-nav-account-fix
python /tmp/loop-nav-account-fix/loop-nav-account-fix/apply_fix.py /workspaces/Loop

cd /workspaces/Loop/loop_work
npm run build
git status
git diff --check

git add   components/Nav.tsx   components/account/WealthFeatureToggle.tsx   app/api/user/wealth-settings/route.ts   domains/identity/account/AccountPage.tsx   components/investments/PensionsInvestmentsClient.tsx

git commit -m "Restore nav dropdowns and autosave account toggles"
git push origin main
```

The patcher creates `*.navfix.bak` backups beside modified files the first time it runs. Do not add those backups to Git.

## Why this is not already pushed

The linked GitHub integration can read `InsideLoopLife/Loop`, but GitHub write calls currently return `403 Resource not accessible by integration`. This bundle is ready to apply in your existing Codespace without claiming it has already been deployed.
