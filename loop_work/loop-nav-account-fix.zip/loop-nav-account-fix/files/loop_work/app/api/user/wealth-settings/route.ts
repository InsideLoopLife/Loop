import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { loadUserFeatureAccess } from "@/lib/features/user-feature-access";

const ALLOWED_FIELDS = new Set([
  "financial_flow_student_loan_enabled",
  "wealth_has_mortgage",
  "wealth_has_pension",
  "wealth_has_investments",
  "wealth_has_savings",
  "wealth_has_credit_cards_or_loans",
  "wealth_has_childcare_costs",
  "wealth_has_car_finance",
  "wealth_has_business_income",
]);

export async function PATCH(request: Request) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const body = await request.json().catch(() => ({}));
  const field = String(body.field || "");

  if (!ALLOWED_FIELDS.has(field)) {
    return NextResponse.json({ error: "Unknown wealth setting" }, { status: 400 });
  }

  if (typeof body.value !== "boolean") {
    return NextResponse.json(
      { error: "Setting value must be true or false" },
      { status: 400 },
    );
  }

  const { error } = await supabase.from("app_user_profiles").upsert(
    {
      user_id: user.id,
      [field]: body.value,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "user_id" },
  );

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  const features = await loadUserFeatureAccess(supabase, user.id).catch(() => null);

  return NextResponse.json({
    ok: true,
    field,
    value: body.value,
    features,
  });
}
