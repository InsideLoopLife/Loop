"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import type { UserFeatureAccess } from "@/lib/features/user-feature-access";

type WealthFeatureToggleProps = {
  name: string;
  label: string;
  description: string;
  checked: boolean;
  setupHref?: string;
  setupLabel?: string;
  location?:
    | "Account"
    | "Financial Flow"
    | "Pensions & Investments"
    | "House"
    | "Income"
    | "LoopWatch";
};

export function WealthFeatureToggle({
  name,
  label,
  description,
  checked,
  setupHref,
  setupLabel = "Add details",
  location = "Account",
}: WealthFeatureToggleProps) {
  const router = useRouter();
  const [enabled, setEnabled] = useState(checked);
  const [status, setStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [message, setMessage] = useState("");
  const inputId = `wealth-toggle-${name}`;

  async function save(next: boolean) {
    const previous = enabled;
    setEnabled(next);
    setStatus("saving");
    setMessage("");

    try {
      const response = await fetch("/api/user/wealth-settings", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ field: name, value: next }),
      });
      const payload = await response.json().catch(() => ({}));

      if (!response.ok) {
        throw new Error(payload?.error || "Unable to save setting.");
      }

      setStatus("saved");
      setMessage("Saved");

      if (payload?.features) {
        window.dispatchEvent(
          new CustomEvent("loop:wealth-feature-changed", {
            detail: {
              features: payload.features as Partial<UserFeatureAccess>,
            },
          }),
        );
      }

      router.refresh();

      window.setTimeout(() => {
        setStatus((current) => (current === "saved" ? "idle" : current));
        setMessage((current) => (current === "Saved" ? "" : current));
      }, 1800);
    } catch (error) {
      setEnabled(previous);
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Could not save.");
    }
  }

  const statusText =
    status === "saving"
      ? "Saving…"
      : status === "saved"
        ? "Saved"
        : status === "error"
          ? message || "Could not save"
          : `Setup lives in ${location}`;

  const statusClass =
    status === "error"
      ? "bg-red-50 text-red-700"
      : status === "saved"
        ? "bg-emerald-50 text-emerald-700"
        : "bg-slate-100 text-slate-500";

  return (
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-indigo-200 hover:shadow-md">
      <div className="flex items-start justify-between gap-4">
        <label htmlFor={inputId} className="min-w-0 flex-1 cursor-pointer">
          <span className="block text-sm font-black text-slate-950">{label}</span>
          <span className="mt-1 block text-xs font-bold leading-5 text-slate-500">{description}</span>
        </label>

        <span className="mt-0.5 shrink-0">
          <input
            id={inputId}
            name={name}
            type="checkbox"
            checked={enabled}
            onChange={(event) => void save(event.target.checked)}
            disabled={status === "saving"}
            aria-label={`Turn ${label} on or off`}
            className="peer sr-only"
          />
          <label
            htmlFor={inputId}
            className="relative block h-7 w-12 cursor-pointer rounded-full bg-slate-200 outline-none ring-indigo-500 transition after:absolute after:left-1 after:top-1 after:h-5 after:w-5 after:rounded-full after:bg-white after:shadow after:transition peer-checked:bg-indigo-600 peer-checked:after:translate-x-5 peer-focus-visible:ring-2 peer-disabled:cursor-wait peer-disabled:opacity-60"
          >
            <span className="sr-only">Turn {label} on or off</span>
          </label>
        </span>
      </div>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-slate-100 pt-3">
        <span
          className={`rounded-full px-3 py-1 text-[10px] font-black uppercase tracking-wide ${statusClass}`}
          role={status === "error" ? "alert" : "status"}
        >
          {statusText}
        </span>

        {setupHref ? (
          <Link href={setupHref} className="text-xs font-black text-indigo-700 hover:text-indigo-900">
            {setupLabel} →
          </Link>
        ) : null}
      </div>
    </div>
  );
}
