#!/usr/bin/env bash
set -euo pipefail
cd /workspaces/Loop/loop_work
SRC="/tmp/loop-house-unified-v7/loop-house-unified-v7"
python "$SRC/apply_v7.py"
cp -f "$SRC/affordability-page.tsx" ./app/affordability/page.tsx
cp -f "$SRC/loading.tsx" ./app/mortgage/loading.tsx
npm run typecheck
cd /workspaces/Loop
git add loop_work/components/Nav.tsx loop_work/components/mortgage/HouseShell.tsx loop_work/components/mortgage/HouseWorkspaceOverview.tsx loop_work/domains/wealth/house/HouseHomePage.tsx loop_work/domains/wealth/house/HousePropertyPage.tsx loop_work/domains/wealth/house/HouseRatesPage.tsx loop_work/domains/wealth/house/HouseMovingCostsPage.tsx loop_work/app/affordability/page.tsx loop_work/app/mortgage/loading.tsx
git diff --cached --check
git commit -m "Unify House workspace and contextual affordability"
git push origin main
