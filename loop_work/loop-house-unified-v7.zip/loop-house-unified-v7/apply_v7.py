from pathlib import Path

# Global nav: paint top-first while the stored preference loads.
p = Path('components/Nav.tsx')
text = p.read_text()
text = text.replace(
    'const [layout, setLayout] = useState<NavigationLayout>("side");',
    'const [layout, setLayout] = useState<NavigationLayout>("top");'
)
p.write_text(text)

# Shared House shell: wider canvas, normal LOOP typography and proactive prefetch.
p = Path('components/mortgage/HouseShell.tsx')
text = p.read_text()
if 'import { useEffect } from "react";' not in text:
    text = text.replace('import Link from "next/link";', 'import Link from "next/link";\nimport { useEffect } from "react";')
text = text.replace('import { usePathname } from "next/navigation";', 'import { usePathname, useRouter } from "next/navigation";')
if 'const router = useRouter();' not in text:
    text = text.replace(
        '  const pathname = usePathname();',
        '''  const pathname = usePathname();\n  const router = useRouter();\n\n  useEffect(() => {\n    [\"/mortgage\", \"/mortgage/property\", \"/mortgage/rates\", \"/affordability\", \"/mortgage/moving-costs\"].forEach((href) => {\n      if (href !== pathname) router.prefetch(href);\n    });\n  }, [pathname, router]);'''
    )
text = text.replace('mx-auto w-[95vw] max-w-[1580px] px-4 py-6 sm:px-6 lg:px-8', 'mx-auto w-[98vw] max-w-[1900px] px-4 py-5 font-sans sm:px-5 lg:px-6 xl:px-8')
text = text.replace('lg:grid-cols-[205px_minmax(0,1fr)]', 'lg:grid-cols-[220px_minmax(0,1fr)]')
text = text.replace('font-black', 'font-bold')
p.write_text(text)

for path in [
    'domains/wealth/house/HouseHomePage.tsx',
    'domains/wealth/house/HousePropertyPage.tsx',
    'domains/wealth/house/HouseRatesPage.tsx',
    'domains/wealth/house/HouseMovingCostsPage.tsx',
    'components/mortgage/HouseWorkspaceOverview.tsx',
]:
    p = Path(path)
    if p.exists():
        p.write_text(p.read_text().replace('font-black', 'font-bold'))

# Add BoE context to House overview if not already present.
p = Path('domains/wealth/house/HouseHomePage.tsx')
text = p.read_text()
if 'createWorkerDatabaseClient' not in text:
    text = text.replace(
        'import { houseValue, loadHouseCore } from "./house-page-data";',
        'import { houseValue, loadHouseCore } from "./house-page-data";\nimport { createWorkerDatabaseClient } from "@/platform/database/worker-client";'
    )
    text = text.replace(
        '  const {homes,deals,valuations}=await loadHouseCore();',
        '  const {homes,deals,valuations}=await loadHouseCore();\n  const ratesDb=createWorkerDatabaseClient("rates");\n  const {data:benchmarks}=await ratesDb.from("mortgage_market_rate_benchmarks").select("term_type, ltv_tier, rate_percent, effective_month").order("effective_month",{ascending:false}).limit(50);'
    )
    text = text.replace(
        '  const payment=Number(deal?.monthly_payment_override||0)||(deal&&balance?calculateMonthlyMortgagePayment({balance,annualInterestRate:Number(deal.interest_rate||0),termYears:Number(deal.term_years||25)}):0);',
        '  const payment=Number(deal?.monthly_payment_override||0)||(deal&&balance?calculateMonthlyMortgagePayment({balance,annualInterestRate:Number(deal.interest_rate||0),termYears:Number(deal.term_years||25)}):0);\n  const bankRate=Number((benchmarks??[]).find((r:any)=>r.term_type==="bank_rate")?.rate_percent||0);\n  const fixedRows=(benchmarks??[]).filter((r:any)=>r.term_type==="2yr_fixed"&&Number(r.rate_percent||0)>0).sort((a:any,b:any)=>Number(a.ltv_tier??100)-Number(b.ltv_tier??100));\n  const benchmark=fixedRows.find((r:any)=>Number(r.ltv_tier??100)>=ltv)??fixedRows.at(-1);\n  const benchmarkRate=Number(benchmark?.rate_percent||0);'
    )
    marker = '    <section className="overflow-hidden rounded-[1.6rem] border border-slate-200 bg-white shadow-sm">'
    block = '''    <section className="grid gap-3 md:grid-cols-2">\n      <article className="rounded-2xl border border-emerald-200 bg-emerald-50/70 p-4 shadow-sm"><p className="text-[10px] font-bold uppercase tracking-[0.11em] text-emerald-700">Bank of England</p><p className="mt-2 text-3xl font-bold text-slate-950">{bankRate>0?`${bankRate.toFixed(2)}%`:"Pending"}</p><p className="mt-1 text-xs font-medium text-slate-600">Current Bank Rate · market context, not a mortgage offer.</p></article>\n      <article className="rounded-2xl border border-violet-200 bg-violet-50/70 p-4 shadow-sm"><p className="text-[10px] font-bold uppercase tracking-[0.11em] text-violet-700">BoE mortgage benchmark</p><p className="mt-2 text-3xl font-bold text-slate-950">{benchmarkRate>0?`${benchmarkRate.toFixed(2)}%`:"Pending"}</p><p className="mt-1 text-xs font-medium text-slate-600">Indicative 2-year fixed benchmark for the nearest available LTV tier.</p></article>\n    </section>\n'''
    text = text.replace(marker, block + marker, 1)
p.write_text(text)
