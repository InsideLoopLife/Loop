LOOP House unified v7

This update unifies the full House experience around the new layout.

Changes:
- House overview, property, mortgage & rates, affordability and moving costs all use the shared HouseShell.
- Affordability pre-fills House and household values but keeps every scenario field editable.
- Current property sale price comes from the current House valuation.
- Current mortgage balance comes from the attached mortgage.
- Gross income comes from active household pay events.
- Child costs use the existing childcare/activity calculation engine.
- Fixed/debt costs come from the spending planner but deliberately exclude mortgage categories to avoid double counting.
- Interest-rate default uses the nearest available BoE 2-year fixed benchmark when available.
- Current equity, LTV and BoE context are shown before scenario inputs.
- House canvas widens to 98vw / max 1900px.
- House routes are prefetched for faster-feeling tab changes.
- A loading skeleton is added for /mortgage.
- Desktop navigation paints top-first while stored preferences load, stopping the sidebar flash/default.
- House Overview gains BoE Bank Rate and mortgage benchmark context.

Install with the ZIP in /workspaces/Loop/loop_work:
cd /workspaces/Loop/loop_work
unzip -o ./loop-house-unified-v7.zip -d /tmp/loop-house-unified-v7
chmod +x /tmp/loop-house-unified-v7/loop-house-unified-v7/install.sh
/tmp/loop-house-unified-v7/loop-house-unified-v7/install.sh
