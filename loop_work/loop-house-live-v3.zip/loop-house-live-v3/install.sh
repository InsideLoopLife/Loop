#!/usr/bin/env bash
set -euo pipefail

cd /workspaces/Loop

cp -f ./loop-house-live-v3/loop_work/domains/wealth/house/HouseOverviewPage.tsx \
  ./loop_work/domains/wealth/house/HouseOverviewPage.tsx

mkdir -p ./loop_work/app/mortgage/advanced
cp -f ./loop-house-live-v3/loop_work/app/mortgage/page.tsx \
  ./loop_work/app/mortgage/page.tsx
cp -f ./loop-house-live-v3/loop_work/app/mortgage/advanced/page.tsx \
  ./loop_work/app/mortgage/advanced/page.tsx

mkdir -p ./loop_work/supabase/migrations
cp -f ./loop-house-live-v3/loop_work/supabase/migrations/20260818_add_lender_tracker_products.sql \
  ./loop_work/supabase/migrations/20260818_add_lender_tracker_products.sql

cd /workspaces/Loop/loop_work
npm run build

cd /workspaces/Loop
git add \
  loop_work/domains/wealth/house/HouseOverviewPage.tsx \
  loop_work/app/mortgage/page.tsx \
  loop_work/app/mortgage/advanced/page.tsx \
  loop_work/supabase/migrations/20260818_add_lender_tracker_products.sql

git commit -m "Make House overview live and add lender tracker formulas"
git push origin main
