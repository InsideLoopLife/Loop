LOOP House live v3

Supabase production has already been updated with lender_tracker_products and authenticated read access.

This package:
- Makes /mortgage render the new responsive House overview.
- Keeps the existing full workspace at /mortgage/advanced.
- Adds lender tracker formulas to the main House experience.
- Seeds NatWest's current representative tracker margin at +0.44% above the NatWest base rate.
- Keeps the distinction between lender-owned base rates and Bank of England Bank Rate.

Install:
1. Unzip this archive into /workspaces/Loop so it creates /workspaces/Loop/loop-house-live-v3
2. Run:
   chmod +x /workspaces/Loop/loop-house-live-v3/install.sh
   /workspaces/Loop/loop-house-live-v3/install.sh
